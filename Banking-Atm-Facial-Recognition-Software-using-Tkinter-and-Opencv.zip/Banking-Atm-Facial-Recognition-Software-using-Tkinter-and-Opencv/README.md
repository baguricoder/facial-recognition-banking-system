# Ayobami-00-Banking-Atm-Facial-Recognition-Software
This is a software which applies computer vision to perform facial recognition as an added layer of security to your bank account. It uses Tkinter for the GUI interface and OpenCv for the facial recognition part.
